# 2.4.3 LAB: Connecting Rancher to Existing AD
Basic documentation for adding azure ad:
https://rancher.com/docs/rancher/v2.x/en/admin-settings/authentication/azure-ad/

## Step 1: Register App In Portal 
## Step 2: Add permissions
## Step 3: Add Client Key
## Step 2: Insert Credentials into Rancher
## Step 3: Add Group Based Permissions in Rancher
