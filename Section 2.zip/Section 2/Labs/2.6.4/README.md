# 2.6.2 LAB: Add storage class and PVC via UI
## Step 1: Rancher UI : Add Storage Class
## Step 2: Rancher UI : Add PV for Project
## Step 3: Rancher UI : Add PVC from PV
## Step 4: kubectl based auto volume assignment