# 2.7.5 LAB: Persistent Storage for P&G via UI
## Step 1: Rancher UI : Monitoring Settings
## Step 2: Rancher UI : Setup Cluster Monitoring
## Step 3: Rancher UI : Enable Persistent Storage
